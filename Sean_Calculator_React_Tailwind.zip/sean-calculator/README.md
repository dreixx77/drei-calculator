# GreenCalc — React + Tailwind Calculator

A modern dark calculator website built for DCIT 26.

## Features

- React + Vite
- Tailwind CSS
- React state and event handling
- Number and operator buttons
- Addition, subtraction, multiplication, and division
- Decimal support
- AC clear/reset
- DEL delete
- Divide-by-zero / invalid-expression handling
- Keyboard support
- Responsive layout
- User Guide on the same page
- Vercel-ready

## Run locally

Requirements: Node.js 18+ recommended.

```bash
npm install
npm run dev
```

Open the local URL shown by Vite, usually `http://localhost:5173`.

## Production test

```bash
npm run build
npm run preview
```

## Deploy to Vercel

### Method 1 — GitHub

1. Create a GitHub repository.
2. Upload this project folder.
3. Push/commit all files.
4. Go to https://vercel.com/
5. Sign in with GitHub.
6. Click **Add New → Project**.
7. Import the calculator repository.
8. Vercel should detect Vite automatically.
9. Build command: `npm run build`
10. Output directory: `dist`
11. Click **Deploy**.
12. Vercel will give you a public URL such as:
   `https://your-project-name.vercel.app`

### Method 2 — Vercel CLI

Install the Vercel CLI:

```bash
npm install -g vercel
```

From the project folder:

```bash
npm install
vercel
```

Follow the prompts. For production deployment:

```bash
vercel --prod
```

## Suggested submission

- Project folder name: use your last name, as required by your instructor.
- Submit the public Vercel URL.
- Example:
  `https://your-calculator.vercel.app`
