import React, { useCallback, useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import { Calculator as CalculatorIcon, Delete, Divide, Equal, RotateCcw } from "lucide-react";
import "./index.css";

const BUTTONS = [
  { label: "AC", type: "action", value: "clear" },
  { label: "DEL", type: "action", value: "delete", icon: true },
  { label: "÷", type: "operator", value: "/" },
  { label: "×", type: "operator", value: "*" },
  { label: "7", type: "number", value: "7" },
  { label: "8", type: "number", value: "8" },
  { label: "9", type: "number", value: "9" },
  { label: "−", type: "operator", value: "-" },
  { label: "4", type: "number", value: "4" },
  { label: "5", type: "number", value: "5" },
  { label: "6", type: "number", value: "6" },
  { label: "+", type: "operator", value: "+" },
  { label: "1", type: "number", value: "1" },
  { label: "2", type: "number", value: "2" },
  { label: "3", type: "number", value: "3" },
  { label: "=", type: "equals", value: "equals", rowSpan: 2 },
  { label: "0", type: "number", value: "0", wide: true },
  { label: ".", type: "number", value: "." },
];

function calculate(expression) {
  if (!expression.trim()) return "0";
  if (!/^[0-9+\-*/().\s]+$/.test(expression)) {
    throw new Error("Invalid expression");
  }

  // Calculator input is restricted to digits/operators above, so evaluation
  // is limited to basic arithmetic expressions.
  const result = Function(`"use strict"; return (${expression})`)();

  if (!Number.isFinite(result)) {
    throw new Error("Cannot divide by zero");
  }

  return String(Number(result.toFixed(10)));
}

function Calculator() {
  const [expression, setExpression] = useState("");
  const [display, setDisplay] = useState("0");
  const [justCalculated, setJustCalculated] = useState(false);
  const [error, setError] = useState("");

  const input = useCallback((value) => {
    setError("");

    if (value === "clear") {
      setExpression("");
      setDisplay("0");
      setJustCalculated(false);
      return;
    }

    if (value === "delete") {
      setExpression((current) => {
        const next = current.slice(0, -1);
        setDisplay(next || "0");
        return next;
      });
      setJustCalculated(false);
      return;
    }

    if (value === "equals") {
      try {
        const result = calculate(expression);
        setDisplay(result);
        setExpression(result === "0" ? "" : result);
        setJustCalculated(true);
      } catch {
        setDisplay("Error");
        setError("Invalid calculation or division by zero.");
        setExpression("");
        setJustCalculated(true);
      }
      return;
    }

    if (justCalculated && /[0-9.]/.test(value)) {
      setExpression(value === "." ? "0." : value);
      setDisplay(value === "." ? "0." : value);
      setJustCalculated(false);
      return;
    }

    if (/[+\-*/]/.test(value)) {
      setExpression((current) => {
        if (!current) return value === "-" ? "-" : current;
        if (/[+\-*/]$/.test(current)) {
          const next = current.slice(0, -1) + value;
          setDisplay(next);
          return next;
        }
        const next = current + value;
        setDisplay(next);
        return next;
      });
      setJustCalculated(false);
      return;
    }

    if (value === ".") {
      const currentNumber = expression.split(/[+\-*/]/).pop() ?? "";
      if (currentNumber.includes(".")) return;
      const next = expression === "" || /[+\-*/]$/.test(expression)
        ? expression + "0."
        : expression + ".";
      setExpression(next);
      setDisplay(next);
      setJustCalculated(false);
      return;
    }

    const next = expression + value;
    setExpression(next);
    setDisplay(next);
    setJustCalculated(false);
  }, [expression, justCalculated]);

  useEffect(() => {
    const handleKeyDown = (event) => {
      const { key } = event;

      if (/^[0-9.]$/.test(key)) {
        event.preventDefault();
        input(key);
      } else if (["+", "-", "*", "/"].includes(key)) {
        event.preventDefault();
        input(key);
      } else if (key === "Enter" || key === "=") {
        event.preventDefault();
        input("equals");
      } else if (key === "Escape") {
        event.preventDefault();
        input("clear");
      } else if (key === "Backspace") {
        event.preventDefault();
        input("delete");
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [input]);

  return (
    <section id="calculator" className="mx-auto w-full max-w-md">
      <div className="overflow-hidden rounded-3xl border border-white/10 bg-zinc-950/90 p-4 shadow-glow backdrop-blur sm:p-5">
        <div className="mb-4 rounded-2xl border border-white/5 bg-black/80 p-5">
          <div className="mb-3 flex items-center justify-between text-xs uppercase tracking-[0.2em] text-zinc-500">
            <span>Display</span>
            <span className="text-green-500">Ready</span>
          </div>
          <div
            className="display-scroll overflow-x-auto whitespace-nowrap text-right font-mono text-3xl font-semibold tracking-tight text-white sm:text-4xl"
            aria-live="polite"
          >
            {display}
          </div>
          {error && (
            <p className="mt-2 text-right text-xs font-medium text-red-400">{error}</p>
          )}
        </div>

        <div className="grid grid-cols-4 gap-3">
          {BUTTONS.map((button) => {
            const base =
              "calculator-button flex min-h-16 items-center justify-center rounded-2xl border text-lg font-semibold focus:outline-none focus:ring-2 focus:ring-green-500/60";
            let style = "border-white/5 bg-zinc-900 text-zinc-100 hover:bg-zinc-800";
            if (button.type === "action") {
              style = "border-white/5 bg-zinc-800 text-zinc-300 hover:bg-zinc-700";
            }
            if (button.type === "operator") {
              style = "border-green-500/10 bg-green-950/60 text-green-400 hover:bg-green-900/70";
            }
            if (button.type === "equals") {
              style = "border-green-400/20 bg-green-500 text-black hover:bg-green-400";
            }

            return (
              <button
                key={button.label}
                type="button"
                onClick={() => input(button.value)}
                aria-label={button.label === "DEL" ? "Delete last character" : button.label}
                className={`${base} ${style} ${button.wide ? "col-span-2" : ""} ${button.rowSpan ? "row-span-2" : ""}`}
              >
                {button.icon ? <Delete size={21} /> : button.label === "=" ? <Equal size={22} /> : button.label}
              </button>
            );
          })}
        </div>

        <div className="mt-4 flex items-center justify-between rounded-xl border border-white/5 bg-zinc-900/60 px-4 py-3 text-xs text-zinc-500">
          <span>Keyboard supported</span>
          <span>ESC = clear · Enter = result</span>
        </div>
      </div>
    </section>
  );
}

function UserGuide() {
  return (
    <section id="guide" className="mx-auto mt-12 w-full max-w-5xl">
      <div className="rounded-3xl border border-white/10 bg-zinc-950/70 p-6 shadow-glow sm:p-8">
        <div className="mb-8 flex items-start gap-4">
          <div className="rounded-2xl bg-green-500/10 p-3 text-green-400">
            <CalculatorIcon size={24} />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">User Guide</h2>
            <p className="mt-1 text-sm text-zinc-400">Everything you need to use the calculator.</p>
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          <GuideCard
            number="01"
            title="Enter numbers"
            text="Click the number buttons to enter a value. You can also use your computer keyboard."
          />
          <GuideCard
            number="02"
            title="Choose an operation"
            text="Use + for addition, − for subtraction, × for multiplication, or ÷ for division."
          />
          <GuideCard
            number="03"
            title="Get your answer"
            text="Press = or Enter to calculate. Use AC to reset everything or DEL to remove the last character."
          />
        </div>

        <div className="mt-8 grid gap-4 md:grid-cols-2">
          <div className="rounded-2xl border border-white/5 bg-black/30 p-5">
            <h3 className="mb-3 font-semibold text-white">Supported Operations</h3>
            <ul className="space-y-2 text-sm text-zinc-400">
              <li><span className="text-green-400">+</span> Addition</li>
              <li><span className="text-green-400">−</span> Subtraction</li>
              <li><span className="text-green-400">×</span> Multiplication</li>
              <li><span className="text-green-400">÷</span> Division</li>
              <li><span className="text-green-400">.</span> Decimal numbers</li>
            </ul>
          </div>
          <div className="rounded-2xl border border-white/5 bg-black/30 p-5">
            <h3 className="mb-3 font-semibold text-white">Keyboard Shortcuts</h3>
            <ul className="space-y-2 text-sm text-zinc-400">
              <li><kbd className="rounded bg-zinc-800 px-2 py-1 text-zinc-200">0–9</kbd> Enter numbers</li>
              <li><kbd className="rounded bg-zinc-800 px-2 py-1 text-zinc-200">+ − * /</kbd> Operators</li>
              <li><kbd className="rounded bg-zinc-800 px-2 py-1 text-zinc-200">Enter</kbd> Calculate</li>
              <li><kbd className="rounded bg-zinc-800 px-2 py-1 text-zinc-200">Backspace</kbd> Delete</li>
              <li><kbd className="rounded bg-zinc-800 px-2 py-1 text-zinc-200">Esc</kbd> Clear</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}

function GuideCard({ number, title, text }) {
  return (
    <div className="rounded-2xl border border-white/5 bg-zinc-900/50 p-5">
      <span className="text-xs font-bold tracking-widest text-green-500">{number}</span>
      <h3 className="mt-3 font-semibold text-white">{title}</h3>
      <p className="mt-2 text-sm leading-6 text-zinc-400">{text}</p>
    </div>
  );
}

function App() {
  return (
    <main className="min-h-screen px-4 py-8 sm:px-6 sm:py-12">
      <header className="mx-auto mb-8 max-w-5xl">
        <div className="flex flex-col items-center justify-between gap-5 text-center sm:flex-row sm:text-left">
          <div>
            <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-green-500/20 bg-green-500/5 px-3 py-1 text-xs font-medium text-green-400">
              <span className="h-1.5 w-1.5 rounded-full bg-green-400" />
              React + Tailwind CSS
            </div>
            <h1 className="text-4xl font-black tracking-tight text-white sm:text-5xl">GreenCalc</h1>
            <p className="mt-2 max-w-xl text-sm leading-6 text-zinc-400">
              A modern, responsive calculator built with React components, state, and event handling.
            </p>
          </div>
          <a
            href="#guide"
            className="rounded-xl border border-white/10 bg-zinc-900 px-4 py-2 text-sm font-medium text-zinc-300 transition hover:border-green-500/30 hover:text-green-400"
          >
            User Guide ↓
          </a>
        </div>
      </header>

      <Calculator />
      <UserGuide />

      <footer className="mx-auto mt-10 max-w-5xl border-t border-white/5 py-6 text-center text-xs text-zinc-600">
        DCIT 26 · Application Development and Emerging Technologies · SY 2026–2027
      </footer>
    </main>
  );
}

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);